from ngsolve import *
import pickle
gfu = pickle.load(open("solution.pickle0", "rb"))
Draw (gfu)
